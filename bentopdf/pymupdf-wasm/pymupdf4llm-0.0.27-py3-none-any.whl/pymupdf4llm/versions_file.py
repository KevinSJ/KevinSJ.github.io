# Generated file - do not edit.
MINIMUM_PYMUPDF_VERSION = (1, 26, 3)
VERSION = '0.0.27'
